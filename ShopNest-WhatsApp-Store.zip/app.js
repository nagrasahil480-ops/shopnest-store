const el = (q, ctx=document)=>ctx.querySelector(q);
const els = (q, ctx=document)=>[...ctx.querySelectorAll(q)];
const state = { products: [], filtered: [], cart: [], categories: new Set(), phone:'+923001234567', theme: localStorage.getItem('theme')||'dark' };

// Theme
const applyTheme = ()=>{
  if(state.theme==='light'){ document.documentElement.classList.add('light'); }
  else { document.documentElement.classList.remove('light'); }
  localStorage.setItem('theme', state.theme);
};
document.addEventListener('DOMContentLoaded', applyTheme);
el('#themeToggle').addEventListener('click', ()=>{ state.theme = state.theme==='light' ? 'dark':'light'; applyTheme(); });

// Load products
fetch('products.json').then(r=>r.json()).then(data=>{
  state.products = data;
  state.filtered = data;
  data.forEach(p=>state.categories.add(p.category));
  renderCategories();
  renderProducts();
  restoreCart();
});

// Search & sort
el('#search').addEventListener('input', e=>{
  const q = e.target.value.toLowerCase();
  state.filtered = state.products.filter(p=>p.title.toLowerCase().includes(q) || p.category.toLowerCase().includes(q));
  renderProducts();
});
el('#sortSelect').addEventListener('change', e=>{
  const v = e.target.value;
  const arr = [...state.filtered];
  if(v==='lh') arr.sort((a,b)=>a.price-b.price);
  if(v==='hl') arr.sort((a,b)=>b.price-a.price);
  if(v==='new') arr.sort((a,b)=>new Date(b.added)-new Date(a.added));
  if(v==='pop') arr.sort((a,b)=>b.pop-a.pop);
  state.filtered = arr;
  renderProducts();
});

// Categories
function renderCategories(){
  const wrap = el('#categoryChips'); wrap.innerHTML='';
  const all = document.createElement('button'); all.className='chip active'; all.textContent='All'; all.onclick=()=>{ 
    els('.chip').forEach(c=>c.classList.remove('active')); all.classList.add('active'); state.filtered = state.products; renderProducts();
  }; wrap.appendChild(all);
  [...state.categories].sort().forEach(cat=>{
    const b = document.createElement('button'); b.className='chip'; b.textContent=cat; b.onclick=()=>{
      els('.chip').forEach(c=>c.classList.remove('active')); b.classList.add('active'); state.filtered = state.products.filter(p=>p.category===cat); renderProducts();
    }; wrap.appendChild(b);
  });
}

// Render products
function renderProducts(){
  const grid = el('#grid'); grid.innerHTML='';
  const tpl = el('#productCardTpl');
  state.filtered.forEach(p=>{
    const node = tpl.content.cloneNode(true);
    const img = el('img', node); img.src = p.image; img.alt = p.title;
    el('.title', node).textContent = p.title;
    el('.desc', node).textContent = p.desc || '';
    el('.price', node).textContent = `Rs ${p.price.toLocaleString()}`;
    el('.tag', node).textContent = p.badge || '';
    el('.add-btn', node).onclick = ()=> addToCart(p.id);
    grid.appendChild(node);
  });
}

// Cart
function saveCart(){ localStorage.setItem('cart', JSON.stringify(state.cart)); updateCartCount(); }
function restoreCart(){ const saved = JSON.parse(localStorage.getItem('cart')||'[]'); state.cart = saved; updateCartCount(); }
function updateCartCount(){ el('#cartCount').textContent = state.cart.reduce((n,i)=>n+i.qty,0); }

function addToCart(id){
  const item = state.cart.find(i=>i.id===id);
  if(item) item.qty+=1;
  else {
    const p = state.products.find(p=>p.id===id);
    state.cart.push({ id, title:p.title, price:p.price, image:p.image, qty:1 });
  }
  saveCart(); renderCart();
  el('#cartDialog').showModal();
}

function renderCart(){
  const wrap = el('#cartItems'); wrap.innerHTML='';
  let sub = 0;
  state.cart.forEach(i=>{
    sub += i.price*i.qty;
    const row = document.createElement('div'); row.className='cart-row';
    row.innerHTML = `
      <img src="${i.image}" alt="${i.title}">
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px">
          <strong>${i.title}</strong>
          <button class="remove">Remove</button>
        </div>
        <div class="qty">
          <button class="dec">-</button><span>${i.qty}</span><button class="inc">+</button>
          <span style="margin-left:auto"><strong>Rs ${(i.price*i.qty).toLocaleString()}</strong></span>
        </div>
      </div>
      <div></div>
    `;
    el('.inc', row).onclick=()=>{ i.qty+=1; saveCart(); renderCart(); };
    el('.dec', row).onclick=()=>{ i.qty=Math.max(1,i.qty-1); saveCart(); renderCart(); };
    el('.remove', row).onclick=()=>{ state.cart = state.cart.filter(x=>x.id!==i.id); saveCart(); renderCart(); };
    wrap.appendChild(row);
  });
  el('#subTotal').textContent = `Rs ${sub.toLocaleString()}`;
  const wa = `https://wa.me/${state.phone.replace(/[^0-9]/g,'')}?text=` + encodeURIComponent(makeOrderText());
  el('#whatsAppCheckout').href = wa;
}
function makeOrderText(){
  if(state.cart.length===0) return 'Hi, I want to order but my cart is empty.';
  const lines = ['New Order from ShopNest','------------------------', ...state.cart.map(i=>`${i.title} x${i.qty} = Rs ${(i.price*i.qty).toLocaleString()}`)];
  const total = state.cart.reduce((n,i)=>n+i.price*i.qty,0);
  lines.push('------------------------', `Subtotal: Rs ${total.toLocaleString()}`, 'Name:', 'City:', 'Address:', 'Phone:');
  return lines.join('\n');
}

el('#cartBtn').addEventListener('click', ()=>{ renderCart(); el('#cartDialog').showModal(); });
el('#year').textContent = new Date().getFullYear();

// Accessibility escape close
el('#cartDialog').addEventListener('click', e=>{
  const dialog = e.currentTarget;
  const rect = dialog.getBoundingClientRect();
  const clickedInDialog = (e.clientX >= rect.left && e.clientX <= rect.right && e.clientY >= rect.top && e.clientY <= rect.bottom);
  if(!clickedInDialog) dialog.close();
});
