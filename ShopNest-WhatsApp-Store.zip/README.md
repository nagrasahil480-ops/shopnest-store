# ShopNest — WhatsApp Checkout Store (Static Site)

This is a **ready-to-upload** mini e‑commerce site. Customers can browse, add to cart, and **checkout via WhatsApp** (Cash on Delivery). No backend needed.

## How to use
1. Replace the placeholder phone number in `app.js`:
   ```js
   const state = { ..., phone:'+923001234567', ... };
   ```
   Use full international format, e.g. `+923001234567`.

2. Add your products in `products.json`. For each product:
   ```json
   {
     "id": 101,
     "title": "Summer Linen Kurta",
     "desc": "100% linen | S-XXL",
     "price": 3499,
     "category": "Fashion",
     "image": "assets/kurta.jpg",
     "badge": "New",
     "added": "2025-08-24",
     "pop": 50
   }
   ```
   - `id`: unique number
   - `price`: in PKR (numbers only)
   - `category`: used for filter chips
   - `image`: path to a JPG/PNG placed inside `assets/`
   - `badge`: optional (e.g., "New", "Hot Deal")
   - `added`: ISO date `YYYY-MM-DD` used for "Newest" sort
   - `pop`: popularity score 0–100 for "Popular" sort

3. Put your product images into the `assets` folder and reference them in `products.json`.

4. Deploy for free:
   - **Netlify**: drag & drop the whole folder in the Netlify dashboard.
   - **GitHub Pages**: push to a repo → Settings → Pages → set branch to `main` and folder to `/`.
   - **Vercel**: import project and deploy as a static site.

## Customization
- **Brand name**: change in `index.html` (header) and cart WhatsApp text in `app.js` (`makeOrderText()`).
- **Theme**: light/dark toggle is built‑in. Default is dark.
- **SEO**: update `<title>` and `<meta name="description">` in `index.html`.
- **Policies**: link your return/refund policy in the footer.

## Tips
- Use compressed images (≤ 200 KB) for faster loading.
- Keep product titles short and descriptive.
- For Instagram, place the site link in your bio and use Story highlights for sizing/FAQs.

Good luck with your sales! 🚀
